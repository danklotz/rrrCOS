# visCOS

**visCOS** is an R-based visualisation tool for COSEROreg. It will be available soon, please do not use the current version. 

**Authors:** Daniel Klotz, Christoph Schürz, Johannes Wesemann, Mathew Herrnegger  
**Maintainer:** Daniel Klotz ([danklotz](https://github.com/danklotz))
***

