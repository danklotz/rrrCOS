/* config.hin.  Generated automatically from configure.in by autoheader.  */
#ifndef CONFIG_H
# define CONFIG_H

/* Define if you have the snprintf function.  */
#define HAVE_SNPRINTF

/* Define if you have the vsnprintf function.  */
#define HAVE_VSNPRINTF

#endif
