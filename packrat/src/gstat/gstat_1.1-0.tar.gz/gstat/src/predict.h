void predict_all(DATA **d);
int is_valid_strata_map(const char *name, int n_vars);
unsigned int *get_n_sim_locs_table(unsigned int *size);
const void *get_mask0(void);
extern unsigned int n_pred_locs;
extern int strata_min;
