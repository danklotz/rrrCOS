# Create parameter boundaries for three parameters
par_bound <- data.frame(par1 = c(0,1), par2 = c(0,1), par3 = c(0,1))

# Apply star sampling within the 3 dimensional parameter space.
par_sample <- sample.STAR(par_bound, 2, 10, "uniform")
