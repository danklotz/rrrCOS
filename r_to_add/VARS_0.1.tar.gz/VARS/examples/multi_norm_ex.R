# Create 3 dimensional grid
n <- 31

par <- expand.grid(x = seq(-1, 1, length.out = n),
                   y = seq(-1, 1, length.out = n),
                   z = seq(-1, 1, length.out = n))

# Calculate probability density for the three dimensions
p_mng <- multi_norm(par, mean = c(0.2,0.5,0), sigma = c(0.7,1,0.5), rho = c(0,0.3,0.9))

# Plot 2d contours for all combinations
p_xy <- p_mng[par$z == 0]
p_xz <- p_mng[par$y == 0]
p_yz <- p_mng[par$x == 0]

par(fig=c(0, 0.5, 0.5, 1))
contour(x = seq(-1, 1, length.out = n),
        y = seq(-1, 1, length.out = n),
        z = matrix(p_xy, n, n),
        xlab = "x", ylab = "y")

par(fig=c(0.5, 1, 0, 0.5), new = TRUE)
contour(x = seq(-1, 1, length.out = n),
        y = seq(-1, 1, length.out = n),
        z = matrix(p_xz, n, n),
        xlab = "x", ylab = "z")

par(fig=c(0, 0.5, 0, 0.5), new = TRUE)
contour(x = seq(-1, 1, length.out = n),
        y = seq(-1, 1, length.out = n),
        z = matrix(p_yz, n, n),
        xlab = "y", ylab = "z")
