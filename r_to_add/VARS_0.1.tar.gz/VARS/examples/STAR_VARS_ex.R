# Create parameter boundaries for three parameters
par_bound <- data.frame(par1 = c(0,1), par2 = c(0,1), par3 = c(0,1))

# Apply star sampling within the three dimensional parameter space.
par_sample <- sample.STAR(par_bound, 2, 50, "uniform")

# Theoretical example for three dimensional response surface
f <- function(par){
  g1 <- function(x) -sin(pi*x) - 0.3*sin(3.33*pi*x)
  g2 <- function(x) -0.76*sin(pi*(x - 0.2)) - 0.315
  g3 <- function(x) -0.12*sin(1.05*pi*(x - 0.2)) - 0.02*sin(95.24*pi*x) - 0.96
  g1(par[1]) + g2(par[2])+ g3(par[3])
}

# Calculate responses for sampled parameter combinations
response <- lapply(par_sample$transect_par, f)

# Derive variograms for the model responses
star_vario <- derive.STAR_VARS(par_sample, response, 25)

# Plot variograms
plot(star_vario$parameter_vario$par1[,1:2], type = "l", log = "y",
     ylim = c(10^-4, 1), col = 4, lwd = 2)
lines(star_vario$parameter_vario$par2[,1:2], type = "l", col = 2, lwd = 2)
lines(star_vario$parameter_vario$par3[,1:2], type = "l", col = 3, lwd = 2)
