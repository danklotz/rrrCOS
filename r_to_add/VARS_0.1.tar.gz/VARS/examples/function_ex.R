par_bounds <- data.frame(x = c(-5,5), y = c(-5,5), z = c(-5,5))
par_sample <- sample.STAR(par_bounds, n_center = 5, n_sample = 100, intervals = "uniform")
response <- lapply(par_sample$transect_par, multi_gauss, sigma = c(1,5,5), rho = c(0,0,0))
star_vario <- derive.STAR_VARS(par_sample, response, 10)

plot(star_vario$parameter_vario$x[,1:2], type = "l",log = "y", ylim = c(10^-10, 10^-2),
     col = 4, lwd = 2)
lines(star_vario$parameter_vario$y[,1:2], type = "l", col = 2, lwd = 2)
lines(star_vario$parameter_vario$z[,1:2], type = "l", col = 3, lwd = 2)


