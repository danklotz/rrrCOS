n <- 100
range_min <-  -2
range_max <-  2
par <- data.frame(par1 = runif(n, range_min, range_max),
                  par2 = runif(n, range_min, range_max))#,
                 # par3 = rep(3, n))
kx <- -1.5
ky <- 4
a <- 1
b <- 100

resp <- 100*multi_norm(par, rho = 0.0, sigma = c(1,5))#+ kx*par$par1 + ky*par$par2
#resp <- f_sin(par)
resp <- f_RB(par, a, b)
res <- cbind.data.frame(par, resp = resp)

var4 <- variog4(coords = res[,1:2], data = res[,3], tolerance = pi/8)
 plot(var4)
 plot(var4$`0`,  type = "l", lwd = 2, col = 2)
 lines(var4$`90`, type = "l", lwd = 2, col = 4)
 lines(var4$`45`, type = "l", col = 3, lty = 2)
 lines(var4$`135`, type = "l", col = 1, lty = 2)


n_plot <- 50
par1 <- seq(range_min, range_max, length.out = n_plot)
par2 <- par1
par <- expand.grid(par1, par2)
z <- f_RB(par,1, 100)
z <- matrix(z, n_plot, n_plot)
contour(z, nlevels = 100)
persp(z)
scatterplot3d(x = par[,1], y = par[,2], z = z$Var1, highlight.3d = TRUE)


# f <- function(par){
#   g1 <- function(x) -sin(pi*x) - 0.3*sin(3.33*pi*x)
#   g2 <- function(x) -0.76*sin(pi*(x - 0.2)) - 0.315
#   # g3 <- function(x) -0.12*sin(1.05*pi*(x - 0.2)) - 0.02*sin(95.24*pi*x) - 0.96
#   g1(par[1]) + 10*g2(par[2])#+ kx*par[1] + ky*par[2]
# }
# f_sin <- function(par) sin(par[1]) - cos(par[2])


# f_RB <- function(par, a, b) (a - par[1])^2 + b*(par[2] - par[1]^2)^2

par_bound <- data.frame(par1 = c(0,1), par2 = c(0,1))

par <- sample.STAR(parameter_bound = par_bound, n_center = 2, n_sample = 15)
resp <- lapply(par$transect_par, f_sin)

var <- derive.STAR_VARS(par, resp)
plot(var$parameter_vario$par1[,1:2], type = "l",
     ylim = c(0, 2), col = 4, lwd = 2)
lines(var$parameter_vario$par2[,1:2], type = "l", col = 2, lwd = 2)

lines3D(x = c(0,0,6,6), y = c(0,6,0,6), z = c(3,3,3,3), colkey = FALSE)

x <- seq(0, 6, length.out = 50)
y <- x
m <- mesh(x,y)
x_m <- m$x
y_m <- m$y

z <- with(m, 3*x+y)
matrix

surf3D(x_m,y_m,z, col = 1, add = TRUE)

points3D(par$par1, par$par2, par$par3, colkey = FALSE, pch = 19, col = 1)
lines3D()





# rearange for variog4 ----------------------------------------------------
par_bound <- data.frame(par1 = c(0,1), par2 = c(0,1))
par <- sample.STAR(parameter_bound = par_bound, n_center = 2, n_sample = 15)
resp <- lapply(par$transect_par, f_RG)


STAR.vario <- function(par_list, resp_list){
par_val <-
  par_list %>%
  zip_n  %>%
  rbind_list() %>%
  lapply(., unlist) %>%
  as.data.frame()

res <- data.frame(par_val, res = unlist(resp_list))

variog4(coords = res[,1:2], data = res[,3], tolerance = 0)
}

var <- STAR.vario(par$transect_norm, resp)

ggVar <- function(var, diag = TRUE){
  var_ortho <- rbind(data.frame(Lag = var$`0`$u,
                               Variance = var$`0`$v,
                               n_Pair = var$`0`$n,
                               angle = "par1"),
                    data.frame(Lag = var$`90`$u,
                               Variance = var$`90`$v,
                               n_Pair = var$`90`$n,
                               angle = "par2"))
  var_ortho$angle %<>%  as.factor()

  ggVar <- ggplot(var_ortho) +
    geom_point(aes(x = Lag, y = Variance, size = n_Pair, col = angle)) +
    geom_line(aes(x = Lag, y = Variance, col = angle)) +
    theme_bw()

  if(diag){
    var_diag <- rbind(data.frame(Lag = var$`45`$u,
                                 Variance = var$`45`$v,
                                 n_Pair = var$`45`$n,
                                 angle = "45"),
                      data.frame(Lag = var$`135`$u,
                                 Variance = var$`135`$v,
                                 n_Pair = var$`135`$n,
                                 angle = "135"))
    var_diag$angle %<>%  as.factor()

    ggVar <- ggVar +
      geom_point(data = var_diag, aes(x = Lag, y = Variance, size = n_Pair, col = angle)) +
      geom_line(data = var_diag, aes(x = Lag, y = Variance, col = angle), linetype = 2) +
      theme_bw()
  }
  return(ggVar)
}


