rng_MNG_min <-  0
rng_MNG_max <-  1

n_samp <- 60
phi <- pi/8
par_MNG_rnd   <- data.frame(par1 = runif(n_samp, rng_MNG_min, rng_MNG_max),
                              par2 = runif(n_samp, rng_MNG_min, rng_MNG_max))
# resp_MNG_rnd  <- multi_norm(par_MNG_rnd, rho = 0)
 resp_MNG_rnd  <- f_RB(par_MNG_rnd,1,100)
# resp_MNG_rnd  <- f_RG(par_MNG_rnd)


geodata_MNG <- cbind(par_MNG_rnd, resp_MNG_rnd) %>%
  as.geodata(., coords.col = 1:2, data.col = 3)


# var_MNG_rnd   <- variog4(coords = par_MNG_rnd, data = resp_MNG_rnd, tolerance = phi, messages = FALSE)
# var4_MNG_rnd <- df_var4(var_MNG_rnd, "phi = 10.0°, n = 250")
#
# ggplot(var4_MNG_rnd) +
#   geom_line(aes(x = Lag, y = Variance, col = angle, linetype = type)) +
#   theme_bw() +
#   theme(legend.title = element_text(size=6), legend.text = element_text(size=6)) +
#   facet_wrap(~meta, ncol = 1)
#
#
#
# n_bins <- ceiling(length(var_MNG_rnd$`0`$u)/2)
# var_th_0 <- smooth.spline(var_MNG_rnd$`0`$u[1:n_bins], var_MNG_rnd$`0`$v[1:n_bins])
# var_th_90 <- smooth.spline(var_MNG_rnd$`90`$u[1:n_bins], var_MNG_rnd$`90`$v[1:n_bins])
# var_th_45 <- smooth.spline(var_MNG_rnd$`45`$u[1:n_bins], var_MNG_rnd$`45`$v[1:n_bins])
# var_th_135 <- smooth.spline(var_MNG_rnd$`135`$u[1:n_bins], var_MNG_rnd$`135`$v[1:n_bins])

grid <- expand.grid(seq(0,1, 0.02),seq(0,1, 0.02))

bin1 <- variog(geodata_MNG, uvec=seq(0,1,l=11))
ols <- variofit(bin1,  fix.nugget = T, cov.model = "cubic", weights = "equal")
plot(bin1)
lines(ols)
kc4 <- krige.conv(geodata_MNG, locations = grid, krige = krige.control(obj.model = ols))
# kc <- krige.control(type.krige = "ok", obj.model = ols, )
contour(kc4, nlevels = 50)




n_samp <- 60

rng_MNG_min <- -1
rng_MNG_max <-  1
par_MNG_rnd   <- data.frame(par1 = runif(n_samp, rng_MNG_min, rng_MNG_max),
                            par2 = runif(n_samp, rng_MNG_min, rng_MNG_max))
resp_MNG_rnd  <- multi_norm(par_MNG_rnd, rho = 0)
geodata_MNG <- cbind(par_MNG_rnd, resp_MNG_rnd) %>%
  as.geodata(., coords.col = 1:2, data.col = 3)

bin_MNG <- variog(geodata_MNG, uvec=seq(0,1,l=11))
var_th_MNG <- variofit(bin_MNG,  fix.nugget = T, cov.model = "gaussian", weights = "equal")
var_df_MNG <- df_var(bin_MNG, "MNG, rho = 0")

gg_var_MNG <- ggVar(var_df_MNG, var_th_MNG, 1)


rng_MNG_cor_min <- -1
rng_MNG_cor_max <-  1
par_MNG_cor_rnd   <- data.frame(par1 = runif(n_samp, rng_MNG_cor_min, rng_MNG_cor_max),
                            par2 = runif(n_samp, rng_MNG_cor_min, rng_MNG_cor_max))
resp_MNG_cor_rnd  <- multi_norm(par_MNG_cor_rnd, rho = 0.8)
geodata_MNG_cor <- cbind(par_MNG_cor_rnd, resp_MNG_cor_rnd) %>%
  as.geodata(., coords.col = 1:2, data.col = 3)

bin_MNG_cor <- variog(geodata_MNG_cor, uvec=seq(0,1,l=11))
var_th_MNG_cor <- variofit(bin_MNG_cor,  fix.nugget = T, cov.model = "gaussian", weights = "equal", )
var_df_MNG_cor <- df_var(bin_MNG_cor, "MNG, rho = 0.8")

gg_var_MNG_cor <- ggVar(var_df_MNG_cor, var_th_MNG_cor, 1)



rng_RG_min <-  0
rng_RG_max <-  1
par_RG_rnd   <- data.frame(par1 = runif(n_samp, rng_RG_min, rng_RG_max),
                           par2 = runif(n_samp, rng_RG_min, rng_RG_max))
resp_RG_rnd  <- f_RG(par_RG_rnd)
geodata_RG <- cbind(par_RG_rnd, resp_RG_rnd) %>%
  as.geodata(., coords.col = 1:2, data.col = 3)

bin_RG <- variog(geodata_RG, uvec=seq(0,1,l=11))
var_th_RG <- variofit(bin_RG,  fix.nugget = T, cov.model = "gaussian", weights = "equal")
var_df_RG <- df_var(bin_RG, "RG")

gg_var_RG <- ggVar(var_df_RG, var_th_RG, 1)

rng_RB_min <- -2
rng_RB_max <-  2
par_RB_rnd   <- data.frame(par1 = runif(n_samp, rng_RB_min, rng_RB_max),
                           par2 = runif(n_samp, rng_RB_min, rng_RB_max))
resp_RB_rnd  <- f_RB(par_RB_rnd,1,100)
geodata_RB <- cbind(par_RB_rnd, resp_RB_rnd) %>%
  as.geodata(., coords.col = 1:2, data.col = 3)

bin_RB <- variog(geodata_RB, uvec=seq(0,1,l=11))
var_th_RB <- variofit(bin_RB,  fix.nugget = T, cov.model = "gaussian", weights = "equal")
var_df_RB <- df_var(bin_RB, "Rosenbrock")

gg_var_RB <- ggVar(var_df_RB, var_th_RB, 1)

grid.arrange(gg_var_RB, gg_var_RG, gg_var_MNG, gg_var_MNG_cor)

grid_RB <- expand.grid(par1 = seq(-2,2, 0.02),par2 = seq(-2,2, 0.02))
kc_RB <- krige.conv(geodata_RB, locations = grid_RB, krige = krige.control(obj.model = var_th_RB))

grid_RG <- expand.grid(par1 = seq(0,1, 0.02),par2 = seq(0,1, 0.02))
kc_RG <- krige.conv(geodata_RG, locations = grid_RG, krige = krige.control(obj.model = var_th_RG))

grid_MNG <- expand.grid(par1 = seq(-1,1, 0.02),par2 = seq(-1,1, 0.02))
kc_MNG <- krige.conv(geodata_MNG, locations = grid_MNG, krige = krige.control(obj.model = var_th_MNG))
kc_MNG_cor <- krige.conv(geodata_MNG_cor, locations = grid_MNG, krige = krige.control(obj.model = var_th_MNG_cor))
kc_MNG_cor1 <- krige.conv(geodata_MNG_cor, locations = grid, krige = krige.control(obj.model = var_th_MNG_cor))



pred_RG <- cbind(grid_RG,pred = kc_RG$predict)
pred_RB <- cbind(grid_RB,pred = kc_RB$predict)
pred_MNG <- cbind(grid_MNG,pred = kc_MNG$predict)
pred_MNG_cor <- cbind(grid_MNG,pred = kc_MNG_cor$predict)
pred_MNG_cor1 <- cbind(grid_MNG,pred = kc_MNG_cor1$predict)

p_RG <- ggplot(pred_RG, aes(x = par1, y = par2, z = pred)) +
  stat_contour(col = "black", bins = 30) +
  theme_bw()

p_RB <- ggplot(pred_RB, aes(x = par1, y = par2, z = pred)) +
  stat_contour(col = "black", bins = 30) +
  theme_bw()

p_MNG <- ggplot(pred_MNG, aes(x = par1, y = par2, z = pred)) +
  stat_contour(col = "black", bins = 30) +
  theme_bw()

p_MNG_cor <- ggplot(pred_MNG_cor, aes(x = par1, y = par2, z = pred)) +
  stat_contour(col = "black", bins = 30) +
  theme_bw()

ggplot(pred_MNG_cor1, aes(x = par1, y = par2, z = pred)) +
  stat_contour(col = "black", bins = 30) +
  theme_bw()

grid.arrange(p_RG, p_RB, p_MNG, p_MNG_cor)

r_RB <- f_RB(grid_RB, 1, 100)
