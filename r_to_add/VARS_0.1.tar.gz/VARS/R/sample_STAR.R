#' Star sampling within a given parameter space
#'
#' Applying Latin Hypercube Sampling, to sample \code{n_center} origins for
#' transects along each parameter dimension within the given parameter space
#' defined by \code{parameter_bound}. Along each transects \code{n_sample}
#' samples are drawn using either \code{"uniform"} or \code{"random"} intervals.
#'
#' @param parameter_bound Data frame holding upper and lower boundary of each
#'   parameter.
#' @param n_center Number of center points for each set of transects.
#' @param n_sample Number of samples along each transect.
#' @param intervals Type of intervals along the transects (either
#'   \code{"uniform"} or \code{"random"} intervals)
#'
#' @return Returns a list containing the parameter combinations of the transect
#'   center points in the normalized parameter space (\code{$center_norm}) and
#'   the actual parameter space (\code{$center_par}) as well as the parameter
#'   combinations of the sampled transects in the normalized parameter space
#'   (\code{$transect_norm}) and the actual parameter space
#'   (\code{$transect_par}).
#' @export
#' @example examples/sample_STAR_ex.R


sample.STAR <- function(parameter_bound, n_center = 2, n_sample = 10, intervals = "uniform"){
  n_par <- ncol(parameter_bound)

# Libraries ---------------------------------------------------------------
  library(magrittr, quietly = TRUE)
  library(lhs,      quietly = TRUE)
  library(plyr,     quietly = TRUE)
  library(dplyr,    quietly = TRUE)
  # options(warn=-1)

# Routine -----------------------------------------------------------------
  center_norm <- optimumLHS(n_center,n_par,2,0.1) %>%
    as.data.frame(.) %>%
    rename.df(.,col_names = colnames(parameter_bound),
              row_names = "center"%_%(1:n_center))

  center_par  <- transform.par(center_norm, parameter_bound, n_center)


  cross_sect_norm <- span.transect(center_norm, n_sample, intervals) %>%
    create.parcomb(., parameter_bound, center_norm, n_par, n_sample, n_center) %<>%
    alply(., 3, .dims = TRUE) %>%
    lapply(., as.data.frame) %>%
    remove.pardupl(.,center_norm)

  cross_sect_par <- lapply(cross_sect_norm, transform.par, parameter_bound,
                           (n_par*n_sample - (n_par - 1)))

  star_samp <- list(center_norm = center_norm,
                    center_par = center_par,
                    transect_norm = cross_sect_norm,
                    transect_par = cross_sect_par)
  return(star_samp)
}


# Subfunctions ------------------------------------------------------------
transform.par <- function(df, parameter_bound, n){
  k <- (parameter_bound[2,] - parameter_bound[1,]) %>%
    .[rep(1,n),]
  d <- parameter_bound[1,] %>%
    .[rep(1,n),]
  df <- df*k +d
  return(df)
}

span.transect <- function(df_center, n_sample, intervals){
  if(intervals == "uniform"){

    star.seq <- function(start_val, step_width){
      seq(start_val, (1 - step_width + start_val), step_width)
    }

    step_width <- 1/n_sample
    lw_bd <- df_center - floor(df_center/step_width)*step_width
    return(apply(t(lw_bd),c(1,2), star.seq, step_width))
  }
  if(intervals == "random"){
    star.rand <- function(center_point, n_sample){
      runif(n_sample - 1) %>%
        c(.,center_point) %>%
        sort
    }

    return(apply(t(df_center), c(1,2), star.rand, n_sample))
  }
}

create.parcomb <- function(par_array, parameter_bound, df_center,
                           n_par, n_sample, n_center){
  par_array %>% apply(., c(2,3), rep, n_par) %>%
    change.dimnames(.,list(paste(rep(colnames(parameter_bound),
                                     each = n_sample),
                                 rep(seq(1,n_sample), n_par),
                                 sep = "_"),
                           colnames(parameter_bound), paste("center",
                                                      seq(1,n_center),
                                                      sep = "_"))) %>%
    replace.fixpar(., df_center, n_par, n_sample, n_center)
}

replace.fixpar <- function(par_array, df_center, n_par, n_sample, n_center){
  par_mask <- diag(n_par) %>%
    apply(., 2, rep, each = n_sample) %>%
    replicate(n_center, ., simplify = "array")

  repl_center <- t(df_center) %>%
    apply(., 2, rep, each = n_par*n_sample) %>%
    array(., dim = c(n_par*n_sample, n_par, n_center))

  repl_matrix <- par_mask %>%
    add(-1) %>%
    abs(.) %>%
    multiply_by(repl_center)

  par_array*par_mask + repl_matrix
}

remove.pardupl <- function(lst_cross_sect, df_center){
  center_names <- names(lst_cross_sect)
  for (i in 1:length(center_names)){
    lst_cross_sect[[center_names[i]]]  %<>%
      rbind.data.frame(center = df_center[i,],.) %>%
      .[!duplicated(.),]
  }
  return(lst_cross_sect)
}
