#' Deriving variograms and covariograms along STAR sampled parameter transects
#'
#' Calculates variance (\code{$var}) and covariance (\code{$cov}) for all sample
#' combinations along each transect for each transect origin (\code{$center_i}).
#' The absolute distances between sample combinations are given by the lag
#' distance (\code{$lag}). The calculated variances (and covariances) along each
#' parameter dimension are averaged for all transect origins. Mean variances and
#' covariances are calculated for (\code{n_bins}) classes along each parameter
#' dimension.
#'
#' @param parameter_STAR List providing all parameter combinations sampled with
#'   \code{sample.STAR()}
#' @param response_STAR List providing Model objective responses for all
#'   parameter combinations in \code{parameter_STAR}. This list requires the
#'   exact same structure of \code{parameter_STAR}
#' @param n_bins Number of uniformly distributed bins for which average variance
#'   and covariance are calculated along each parameter dimension.
#'
#' @return Returns a list providing variance and covariance for all sample
#'   combinations along each transect (\code{$par_i}) in each transect origin
#'   (\code{$center_i}) arranged in the sub list \code{$center_vario} and
#'   providing the average variances and covariances for each parameter given in
#'   the sub list \code{$parameter_vario}
#' @export
#' @example examples/STAR_VARS_ex.R
#'
derive.STAR_VARS <- function(parameter_STAR, response_STAR, n_bins = 10){
# Libraries ---------------------------------------------------------------
  library(magrittr, quietly = TRUE)
  library(plyr,     quietly = TRUE)
  library(dplyr,    quietly = TRUE)
  library(purrr,    quietly = TRUE)
  # options(warn=-1)

# Routine -----------------------------------------------------------------
  star_vars <- list()
  star_vars$center_vario <- calc.variogram(parameter_STAR, response_STAR)
  star_vars$parameter_vario <- binned.variogram(star_vars$center_vario,
                                                n_bins)
  return(star_vars)
}


# Subfunctions ------------------------------------------------------------
## calc.variogram() -------------------- ----------------------------------
calc.var_center_i <- function(df_center_i, response_i){
  par_names <- colnames(df_center_i)
  calc.var_single_par <- function(par_name, df_center_i, response_i){
    options(warn=-1)
    response_i %>%
      unname %>%
      cbind.data.frame(df_center_i, res = .) %>%
      select(., which(colnames(.) == par_name), res) %>%
      .[which(rownames(.) == "center" |
                substr(rownames(.), 1, nchar(par_name)) == par_name),] %>%
      arrange(.,.[,1]) %>%
      cbind.data.frame(expand.grid(.[,1],.[,1]),
                       expand.grid(.[,2],.[,2])) %>%
      .[,3:6] %>%
      rename.df(., col_names = c("lag1", "lag2", "res1", "res2")) %>%
      mutate(., lag = lag1 - lag2,
             var = 0.5*(res1 - res2)^2,
             cov = (res1 - mean(res1))*(res2 - mean(res2))) %>%
      select(., lag, var, cov) %>%
      filter(., lag >= 0)
  }

  var <- lapply(par_names, calc.var_single_par, df_center_i, response_i)
  names(var) <- par_names
  return(var)
}

calc.variogram <- function(par_list, response_list){
  center_names <- names(par_list[["transect_norm"]])
  calc.var_center_wrapper <- function(center_i, par_list, response_list){
    calc.var_center_i(par_list$transect_norm[[center_i]],
                      response_list[[center_i]])
  }
  var <- lapply(center_names, calc.var_center_wrapper, par_list, response_list)
  names(var) <- center_names
  return(var)
}


## binned.vario(lag, val, breaks) -----------------------------------------
binned.variogram <- function(center_var, n_bins){
  center_var %<>% zip_n
  par_names <- names(center_var)
  for (i in par_names) center_var[[i]] %<>% rbind_all

  bins <- data.frame(lw_bd = seq(0, 1, length.out = n_bins + 1)[1:n_bins],
                     up_bd = seq(0, 1, length.out = n_bins + 1)[2:(n_bins+1)])

  calc.bin_var <- function(bound, df_var){
    df_var %>%
      filter(., lag > bound[1], lag <= bound[2]) %>%
      mutate(., lag = (bound[2] - bound[1])/2 + bound[1]) %>%
      colMeans(.)
  }

  calc.bin_var_wrapper <- function(df_var, bins){
    apply(bins, 1, calc.bin_var, df_var) %>%
      t
  }
  lapply(center_var, calc.bin_var_wrapper, bins)
}
