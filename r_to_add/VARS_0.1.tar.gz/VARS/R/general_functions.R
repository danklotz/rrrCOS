# General functions -------------------------------------------------------
rename.df <- function(df, col_names = NULL, row_names = NULL){
  if(!is.null(row_names)){
    rownames(df) <- row_names
  }
  if(!is.null(col_names)){
    colnames(df) <- col_names
  }
  return(df)
}

change.dimnames <- function(arr, list_dimnames){
  dimnames(arr) <- list_dimnames
  return(arr)
}

# Some infix paste functions ---------------------------------------------
'%_%' <- function(a, b) paste(a, b, sep = "_")
'%.%' <- function(a, b) paste(a, b, sep = ".")
'%/%' <- function(a, b) paste(a, b, sep = "/")
