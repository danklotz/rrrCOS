#' Multivariate normal distribution
#'
#' Provides the densitiy function for the multivariate normal distribution for
#' \code{x}, with mean equal to \code{mean}, variance equal to \code{sigma} and
#' correlation of dimensions equal to \code{rho}.
#'
#' @param x matrix holding coodinates for which probability density is
#'   calculated
#' @param mean vector of dimension means
#' @param sigma vector of dimension variances
#' @param rho vector of dimension correlations (e.g. dimensions = a,b,c,d; rho = c(ab, ac, ad, bc, bd, cd))
#'
#' @return density mulit norm
#' @export
#' @example examples/multi_norm_ex.R
multi_norm <- function(x, mean = rep(0, length(x)), sigma = rep(1, length(x)), rho = rep(0, length(x)*(length(x) + 1)/2)){
  sigma_mat <- sigma.matr(sigma, rho)
  multi_gauss_x <- function(x_i, mean, sigma, rho){
    1/sqrt((2*pi)^length(x_i)*det(sigma_mat)) *
      exp(-1/2 * t(x_i - mean)%*%solve(sigma_mat)%*%(x_i - mean))
  }

  apply(x, 1, multi_gauss_x, mean, sigma, rho)
}



# Subfunctions ------------------------------------------------------------
sigma.matr <- function(sigma_i, rho_i){
  rho <- rho.matr(rho_i)
  sigma <- outer(sigma_i, sigma_i, "*") *
    (rho + diag(length(sigma_i)))
  return(sigma)
}

rho.matr <- function(rho_i){
  n <- 0.5*(1 + sqrt(1 + 8*length(rho_i)))
  vec <- c()
  ind <- 1
  for(i in 1:n){
    if(ind <= length(rho_i)){
      rho_add <- rho_i[ind:((ind - 1) + (n - i))]
    } else {
      rho_add <- c()
    }
    vec <- c(vec, rep(0,i), rho_add)
    ind <- ind + (n - i)
  }
  mat <- matrix(vec,n,n)
  mat <- mat + t(mat)
  return(mat)
}
