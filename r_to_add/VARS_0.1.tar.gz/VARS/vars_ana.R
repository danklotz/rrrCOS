
# Libraries ###############################################################
require(magrittr)
require(lhs)
require(plyr)
require(dplyr)
require(purrr)


# Functions ###############################################################
## star.samp(par_bound, n_center, step_width) -----------------------------
star.samp <- function(par_bound, n_center, n_step, step_type = "uniform"){
  n_par <- ncol(par_bound)

  center_norm <- optimumLHS(n_center,n_par,2,0.1) %>%
    as.data.frame(.) %>%
    rename.df(.,col_names = colnames(par_bound),
                row_names = 1:n_center)

  center_par  <- transform.par(center_norm, par_bound, n_center)


  cross_sect_norm <- span.transect(center_norm, n_step, step_type) %>%
    create.parcomb(., par_bound, center_norm, n_par, n_step, n_center) %<>%
    alply(., 3, .dims = TRUE) %>%
    lapply(., as.data.frame) %>%
    remove.pardupl(.,center_norm)

  cross_sect_par <- lapply(cross_sect_norm, transform.par, par_bound,
                           (n_par*n_step - (n_par - 1)))

  star_samp <- list(center_norm = center_norm,
                    center_par = center_par,
                    cross_sect_norm = cross_sect_norm,
                    cross_sect_par = cross_sect_par)
  return(star_samp)
}
### star.samp Subfunctions ---
transform.par <- function(df, par_bound, n){
  k <- (par_bound[2,] - par_bound[1,]) %>%
    .[rep(1,n),]
  d <- par_bound[1,] %>%
    .[rep(1,n),]
  df <- df*k +d
  return(df)
}

span.transect <- function(df_center, n_step, step_type){
  if(step_type == "uniform"){

    star.seq <- function(start_val, step_width){
      seq(start_val, (1 - step_width + start_val), step_width)
    }

    step_width <- 1/n_step
    lw_bd <- df_center - floor(df_center/step_width)*step_width
    return(apply(t(lw_bd),c(1,2), star.seq, step_width))
  }
  if(step_type == "random"){
    star.rand <- function(center_point, n_step){
      runif(n_step - 1) %>%
        c(.,center_point) %>%
        sort
    }

    return(apply(t(df_center), c(1,2), star.rand, n_step))
  }
}

rename.df <- function(df, col_names = NULL, row_names = NULL){
  if(!is.null(row_names)){
    rownames(df) <- row_names
  }
  if(!is.null(col_names)){
    colnames(df) <- col_names
  }
  return(df)
}

change.dimnames <- function(arr, list_dimnames){
  dimnames(arr) <- list_dimnames
  return(arr)
}

create.parcomb <- function(par_array, par_bound, df_center,
                           n_par, n_step, n_center){
  par_array %>% apply(., c(2,3), rep, n_par) %>%
    change.dimnames(.,list(paste(rep(colnames(par_bound), each = n_step),
                                 rep(seq(1,n_step), n_par),
                                 sep = "_"),
                           colnames(par_bound), paste("center",
                                                      seq(1,n_center),
                                                      sep = "_"))) %>%
    replace.fixpar(., df_center, n_par, n_step, n_center)
}

replace.fixpar <- function(par_array, df_center, n_par, n_step, n_center){
  par_mask <- diag(n_par) %>%
    apply(., 2, rep, each = n_step) %>%
    replicate(n_center, ., simplify = "array")

  repl_center <- t(df_center) %>%
    apply(., 2, rep, each = n_par*n_step) %>%
    array(., dim = c(n_par*n_step, n_par, n_center))

  repl_matrix <- par_mask %>%
    add(-1) %>%
    abs(.) %>%
    multiply_by(repl_center)

  par_array*par_mask + repl_matrix
}

remove.pardupl <- function(lst_cross_sect, df_center){
  center_names <- names(lst_cross_sect)
  for (i in 1:length(center_names)){
    lst_cross_sect[[center_names[i]]]  %<>%
      rbind.data.frame(center = df_center[i,],.) %>%
      .[!duplicated(.),]
  }
  return(lst_cross_sect)
}

## calc.var() -------------------------------------------------------------
calc.var_center_i <- function(df_par_i, response_i){
  par_names <- colnames(df_par_i)
  calc.var_single_par <- function(par_name, df_par_i, response_i){ 
    options(warn=-1)
    response_i %>% 
      unname %>% 
      cbind.data.frame(df_par_i, res = .) %>% 
      select(., which(colnames(.) == par_name), res) %>% 
      .[which(rownames(.) == "center" | 
              substr(rownames(.), 1, nchar(par_name)) == par_name),] %>% 
      arrange(.,.[,1]) %>% 
      cbind.data.frame(expand.grid(.[,1],.[,1]), 
                       expand.grid(.[,2],.[,2])) %>% 
      .[,3:6] %>% 
      rename.df(., col_names = c("lag1", "lag2", "res1", "res2")) %>% 
      mutate(., lag = lag1 - lag2,
                var = 0.5*(res1 - res2)^2,
                cov = (res1 - mean(res1))*(res2 - mean(res2))) %>% 
      select(., lag, var, cov) %>% 
      filter(., lag >= 0)
  }
  
  var <- lapply(par_names, calc.var_single_par, df_par_i, response_i)
  names(var) <- par_names
  return(var)
}

calc.var <- function(par_list, response_list){
  center_names <- names(sens_list[["cross_sect_norm"]])
  calc.var_center_wrapper <- function(center_i, par_list, response_list){
    calc.var_center_i(par_list[[center_i]],
                      response_list[[center_i]])
  }
  
  var <- lapply(center_names, calc.var_center_wrapper, par_list, response_list)
  names(var) <- center_names
  return(var)
}

## binned.vario(lag, val, breaks) -----------------------------------------
binned.vario <- function(center_var, n_bins){
  center_var %<>% zip_n
  par_names <- names(center_var)
  for (i in par_names) center_var[[i]] %<>% rbind_all
  
  bins <- data.frame(lw_bd = seq(0, 1, length.out = n_bins + 1)[1:n_bins],
                     up_bd = seq(0, 1, length.out = n_bins + 1)[2:(n_bins+1)])
  
  calc.bin_var <- function(bound, df_var){
    df_var %>% 
      filter(., lag > bound[1], lag <= bound[2]) %>% 
      mutate(., lag = (bound[2] - bound[1])/2 + bound[1]) %>% 
      colMeans(.)
  }
  
  calc.bin_var_wrapper <- function(df_var, bins){
    apply(bins, 1, calc.bin_var, df_var) %>% 
      t
  }
  lapply(center_var, calc.bin_var_wrapper, bins)
  
  
  gam <- c()
  h_m <- c()
  for (i in 1:length(breaks)){
    if(i == 1) {bin_bound <- c(0,breaks[1])}
    else       {bin_bound <- c(breaks[i - 1], breaks[i])}
    val_sel <- val[lag > bin_bound[1] & lag <= bin_bound[2]]
    gam <- c(gam, sum(val_sel)/length(val_sel))
    h_m <- c(h_m, mean(bin_bound))
  }
  df <- data.frame(h = h_m, gam = gam)
  return(df)
}


star_samp$response <- lapply(star_samp$cross_sect_par, f)

# Execute #################################################################
f1 <- function(x) sin(pi*(0.2 - x))

x <- runif(10)
x <- seq(0,1, length.out = 50)
y <- f1(x)
y_m <- mean(y)
df <- data.frame(expand.grid(x,x), expand.grid(y,y))

var <- data.frame(h = df[,1] - df[,2],
                  gam = 0.5*(df[,3] - df[,4])^2,
                  cov = (df[,3] - y_m)*(df[,4] - y_m))
var <- var[var$h > 0,]



plot(var$h, var$gam, ylim = c(-0.75, 1.5))
points(var$h, var$cov, col = 2)


x1 <- seq(0,1, length.out = 500)
x2 <- x1
x3 <- x1
x4 <- x1
x5 <- x1
x6 <- x1

g1 <- function(x) -sin(pi*x) - 0.3*sin(3.33*pi*x)
g2 <- function(x) -0.76*sin(pi*(x - 0.2)) - 0.315
g3 <- function(x) -0.12*sin(1.05*pi*(x - 0.2)) - 0.02*sin(95.24*pi*x) - 0.96
g4 <- function(x) -0.12*sin(1.05*pi*(x - 0.2)) - 0.96
g5 <- function(x) -0.05*sin(pi*(x - 0.2)) - 1.02
g6 <- function(x) -1.08

f <- function(par){
  g1 <- function(x) -sin(pi*x) - 0.3*sin(3.33*pi*x)
  g2 <- function(x) -0.76*sin(pi*(x - 0.2)) - 0.315
  g1(par[1]) + g2(par[2])
}



# grid.lhs ----------------------------------------------------------------
# center_norm <- grid.lhs(par_bound,n_center, step_width)
# center_par  <- transform.centers(center_norm,par_bound)
#
# center_expand <- apply(center_norm, 2, rep, each = 10)
#
# star_sect <- list()
# for (i in 1:ncol(center_norm)){
#   star_sect[[i]] <- center_expand %>%
#     replace(.,
#             c(1:nrow(.),i),
#             rep(step_width*(1:nrow(.)), n)
# }
#
#
#
#
# grid.lhs <- function(par_bound, n_center, step_width){
#   optimumLHS(n_center,dim(par_bound)[2],2,0.1) %>%
#     apply(., c(1,2), stick.grid, seq(0, 1, step_width)) %>%
#     rename.df(.,colnames(par_bound), 2) %>%
#     rename.df(.,1:n_center, 1)
# }
#
#

#
# stick.grid <- function(val, grid_seq){
#   grid_seq[which.min(abs(grid_seq-val))]
# }
#--------------------------------------------------------------------------








# test ---------------------------------------------------------------




par_bound <- data.frame(par1 = c(0,1), par2 = c(0,1))
star_samp <- star.samp(par_bound, 3, 10, "uniform")
plot(star_samp$cross_sect_par$center_1, xlim = c(3,15), ylim = c(-2,5))
points(star_samp$cross_sect_par$center_2)
points(star_samp$cross_sect_par$center_3)
points(star_samp$center_par, pch = 3)

plot(star_samp$cross_sect_norm$center_1, xlim = c(0,1), ylim = c(0,1))
points(star_samp$cross_sect_norm$center_2)
points(star_samp$center_norm, pch = 3)

plot(cross_sect_norm$center_1, xlim = c(0,1), ylim = c(0,1))
points(cross_sect_norm$center_2)
points(center_norm, pch = 3)


n_center <- 3
n_step <- 10
step_type <- "uniform"
step_type <- "random"
